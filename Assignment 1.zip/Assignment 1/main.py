import re

def validate_email(email):
    emailFile = open("EmailDB.txt","r")
    emailArr = emailFile.readlines()
    emailArr1=[]
    if(len(emailArr) >0):
        emailArr1=emailArr[0].split(',')
    if(email in emailArr1):
        print("Email Id Already Exists!")
        login()
        return False
    else:
        regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        if(re.fullmatch(regex, email)):
            print("Valid Email")
            return True
        else:
            print("Invalid Email")
            register()

def validate_password(password):
    print(len(password))
    if (len(password) > 5 and len(password) < 16):
        d=0
        l=0
        u=0
        p=0
        for i in password:
            # counting lowercase alphabets
            if (i.islower()):
                l+=1           
     
            # counting uppercase alphabets
            if (i.isupper()):
                u+=1           
     
            # counting digits
            if (i.isdigit()):
                d+=1           
     
            # counting the mentioned special characters
            if(i=='@'or i=='$' or i=='_'):
                p+=1          
        if (l>=1 and u>=1 and p>=1 and d>=1 and l+p+u+d==len(password)):
           print("Valid Password")
           return True
        else:
           print("Invalid Password")
           print("Must have minimum one special character, one digit, one uppercase, one lowercase character ")
           return False
    else:
        print("Invalid Password")
        print("Must have minimum 5 Characters and Maximum 16 Characters ")
        return False

        
def register():
    print("Register User!!!")
    email = str(input("Enter the Email Id: "))
    check1=validate_email(email)
    if(check1==True):
        password = str(input("Enter the Password: "))
        passCheck = validate_password(password)
        if(passCheck==True):
            emailFile = open("EmailDB.txt","a")
            emailFile.write(","+email)
            emailFile.write(","+password)
            emailFile.close()
            print("Registration Sucessfull!!")
            print("*")
            print("*")
            print("*")
            print("*")
            print("*")
            print("*")
            welocme_portal()
        else:
             register()


def validateCred(email,password):
    emailFile = open("EmailDB.txt","r")
    emailArr = emailFile.readlines()
    emailArr1=[]
    if(len(emailArr) >0):
        emailArr1=emailArr[0].split(',') 
    if(email in emailArr1):
        ind = emailArr1.index(email)
        if(password==emailArr1[ind+1]):
            return True
        else:
            print("Wrong Password!!!!!")
            print("Enter 1 to get password / Enter 2 to relogin / Enter 3 to Home page:")
            q = int(input())
            if(q==1):
                print("Your Password is : ",emailArr1[ind+1])
                return False
            elif(q==2):
                login()
            elif(q==3):
                welocme_portal()
            else:
                return False
    else:
        return False
def login():
    print("Login User!!!")
    email = str(input("Enter the Email Id: "))
    password = str(input("Enter the Password: "))
    check = validateCred(email,password)
    if(check == True):
        print("**** Login Sucessfull!! ****")
    else:
        print("**** Login Failed!! ****")
    print("*")
    print("*")
    print("*")
    print("*")
    print("*")
    print("*")
    welocme_portal()
    
def welocme_portal():
    print("**** Welcome To XYZ Portal! ****")
    print("Enter 1 to Register / Enter 2 to login")
    co=int(input("1/2 : "))
    if(co==1):
        register()
    if(co==2):
        login()
        
welocme_portal()
     
